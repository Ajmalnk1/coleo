<?php
/* Contact Form 7 support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if (!function_exists('coleo_cf7_theme_setup9')) {
	add_action( 'after_setup_theme', 'coleo_cf7_theme_setup9', 9 );
	function coleo_cf7_theme_setup9() {

		if (is_admin()) {
			add_filter( 'coleo_filter_tgmpa_required_plugins',			'coleo_cf7_tgmpa_required_plugins' );
		}
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'coleo_cf7_tgmpa_required_plugins' ) ) {
	
	function coleo_cf7_tgmpa_required_plugins($list=array()) {
		if (coleo_storage_isset('required_plugins', 'contact-form-7')) {
			// CF7 plugin
			$list[] = array(
					'name' 		=> coleo_storage_get_array('required_plugins', 'contact-form-7'),
					'slug' 		=> 'contact-form-7',
					'required' 	=> false
			);
		}
		return $list;
	}
}



// Check if cf7 installed and activated
if ( !function_exists( 'coleo_exists_cf7' ) ) {
	function coleo_exists_cf7() {
		return class_exists('WPCF7');
	}
}
?>