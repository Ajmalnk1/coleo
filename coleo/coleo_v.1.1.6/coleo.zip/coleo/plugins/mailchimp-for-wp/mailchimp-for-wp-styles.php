<?php
// Add plugin-specific colors and fonts to the custom CSS
if (!function_exists('coleo_mailchimp_get_css')) {
	add_filter('coleo_filter_get_css', 'coleo_mailchimp_get_css', 10, 4);
	function coleo_mailchimp_get_css($css, $colors, $fonts, $scheme='') {
		
		if (isset($css['fonts']) && $fonts) {
			$css['fonts'] .= <<<CSS
form.mc4wp-form .mc4wp-form-fields input[type="email"] {
	{$fonts['input_font-family']}
	{$fonts['input_font-size']}
	{$fonts['input_font-weight']}
	{$fonts['input_font-style']}
	{$fonts['input_line-height']}
	{$fonts['input_text-decoration']}
	{$fonts['input_text-transform']}
	{$fonts['input_letter-spacing']}
}
form.mc4wp-form .mc4wp-form-fields input[type="submit"] {
	{$fonts['button_font-family']}
	{$fonts['button_font-size']}
	{$fonts['button_font-weight']}
	{$fonts['button_font-style']}
	{$fonts['button_line-height']}
	{$fonts['button_text-decoration']}
	{$fonts['button_text-transform']}
	{$fonts['button_letter-spacing']}
}

CSS;
		
			
			$rad = coleo_get_border_radius();
			$css['fonts'] .= <<<CSS

form.mc4wp-form .mc4wp-form-fields input[type="email"],
form.mc4wp-form .mc4wp-form-fields input[type="submit"] {
	-webkit-border-radius: {$rad};
	    -ms-border-radius: {$rad};
			border-radius: {$rad};
}

CSS;
		}

		
		if (isset($css['colors']) && $colors) {
			$css['colors'] .= <<<CSS

form.mc4wp-form .mc4wp-alert {
	background-color: {$colors['text_dark']};
	border-color: {$colors['text_hover']};
	color: {$colors['inverse_text']};
}
form.mc4wp-form .mc4wp-alert a:hover{
	color: {$colors['text']};
}
form.mc4wp-form span.arrow:before{ color: {$colors['extra_bd_hover']};}
form.mc4wp-form span.arrow:hover:before{ color: {$colors['text_link']};}

form.mc4wp-form .mc4wp-form-fields input[type="email"] {
	border-color: {$colors['text_light']};
}

.scheme_dark form.mc4wp-form input[type="email"]::-webkit-input-placeholder{ color: {$colors['extra_dark']}; }
.scheme_dark form.mc4wp-form input[type="email"]::-moz-placeholder{ color: {$colors['extra_dark']}; }
.scheme_dark form.mc4wp-form input[type="email"]:-ms-input-placeholder { color: {$colors['extra_dark']}; }
.scheme_dark form.mc4wp-form input[type="email"]::placeholder	{ color: {$colors['extra_dark']};}
.scheme_dark form.mc4wp-form input[type="email"] { color: {$colors['extra_dark']};}





CSS;
		}

		return $css;
	}
}
?>