<?php
/**
 * The template to display posts in widgets and/or in the search results
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

$coleo_post_id    = get_the_ID();
$coleo_post_date  = coleo_get_date();
$coleo_post_title = get_the_title();
$coleo_post_link  = get_permalink();
$coleo_post_author_id   = get_the_author_meta('ID');
$coleo_post_author_name = get_the_author_meta('display_name');
$coleo_post_author_url  = get_author_posts_url($coleo_post_author_id, '');

$coleo_args = get_query_var('coleo_args_widgets_posts');
$coleo_show_date = isset($coleo_args['show_date']) ? (int) $coleo_args['show_date'] : 1;
$coleo_show_image = isset($coleo_args['show_image']) ? (int) $coleo_args['show_image'] : 1;
$coleo_show_author = isset($coleo_args['show_author']) ? (int) $coleo_args['show_author'] : 1;
$coleo_show_counters = isset($coleo_args['show_counters']) ? (int) $coleo_args['show_counters'] : 1;
$coleo_show_categories = isset($coleo_args['show_categories']) ? (int) $coleo_args['show_categories'] : 1;

$coleo_output = coleo_storage_get('coleo_output_widgets_posts');

$coleo_post_counters_output = '';
if ( $coleo_show_counters ) {
	$coleo_post_counters_output = '<span class="post_info_item post_info_counters">'
								. coleo_get_post_counters('comments')
							. '</span>';
}


$coleo_output .= '<article class="post_item with_thumb">';

if ($coleo_show_image) {
	$coleo_post_thumb = get_the_post_thumbnail($coleo_post_id, coleo_get_thumb_size('tiny'), array(
		'alt' => the_title_attribute( array( 'echo' => false ) )
	));
	if ($coleo_post_thumb) $coleo_output .= '<div class="post_thumb">' . ($coleo_post_link ? '<a href="' . esc_url($coleo_post_link) . '">' : '') . ($coleo_post_thumb) . ($coleo_post_link ? '</a>' : '') . '</div>';
}

$coleo_output .= '<div class="post_content">'
			. ($coleo_show_categories 
					? '<div class="post_categories">'
						. coleo_get_post_categories()
						. $coleo_post_counters_output
						. '</div>' 
					: '')
			. '<h6 class="post_title">' . ($coleo_post_link ? '<a href="' . esc_url($coleo_post_link) . '">' : '') . ($coleo_post_title) . ($coleo_post_link ? '</a>' : '') . '</h6>'
			. apply_filters('coleo_filter_get_post_info', 
								'<div class="post_info">'
									. ($coleo_show_date 
										? '<span class="post_info_item post_info_posted">'
											. ($coleo_post_link ? '<a href="' . esc_url($coleo_post_link) . '" class="post_info_date">' : '') 
											. esc_html($coleo_post_date) 
											. ($coleo_post_link ? '</a>' : '')
											. '</span>'
										: '')
									. ($coleo_show_author 
										? '<span class="post_info_item post_info_posted_by">' 
											. esc_html__('by', 'coleo') . ' ' 
											. ($coleo_post_link ? '<a href="' . esc_url($coleo_post_author_url) . '" class="post_info_author">' : '') 
											. esc_html($coleo_post_author_name) 
											. ($coleo_post_link ? '</a>' : '') 
											. '</span>'
										: '')
									. (!$coleo_show_categories && $coleo_post_counters_output
										? $coleo_post_counters_output
										: '')
								. '</div>')
		. '</div>'
	. '</article>';
coleo_storage_set('coleo_output_widgets_posts', $coleo_output);
?>