<?php
/**
 * The template to display the socials in the footer
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0.10
 */


// Socials
if ( coleo_is_on(coleo_get_theme_option('socials_in_footer')) && ($coleo_output = coleo_get_socials_links()) != '') {
	?>
	<div class="footer_socials_wrap socials_wrap">
		<div class="footer_socials_inner">
			<?php coleo_show_layout($coleo_output); ?>
		</div>
	</div>
	<?php
}
?>