<?php
/**
 * The template to display the site logo in the footer
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0.10
 */

// Logo
if (coleo_is_on(coleo_get_theme_option('logo_in_footer'))) {
	$coleo_logo_image = '';
	if (coleo_is_on(coleo_get_theme_option('logo_retina_enabled')) && coleo_get_retina_multiplier(2) > 1)
		$coleo_logo_image = coleo_get_theme_option( 'logo_footer_retina' );
	if (empty($coleo_logo_image)) 
		$coleo_logo_image = coleo_get_theme_option( 'logo_footer' );
	$coleo_logo_text   = get_bloginfo( 'name' );
	if (!empty($coleo_logo_image) || !empty($coleo_logo_text)) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if (!empty($coleo_logo_image)) {
					$coleo_attr = coleo_getimagesize($coleo_logo_image);
					echo '<a href="'.esc_url(home_url('/')).'"><img src="'.esc_url($coleo_logo_image).'" class="logo_footer_image" alt="'.esc_attr(basename($coleo_logo_image)).'"'.(!empty($coleo_attr[3]) ? ' ' . wp_kses_data($coleo_attr[3]) : '').'></a>' ;
				} else if (!empty($coleo_logo_text)) {
					echo '<h1 class="logo_footer_text"><a href="'.esc_url(home_url('/')).'">' . esc_html($coleo_logo_text) . '</a></h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
?>