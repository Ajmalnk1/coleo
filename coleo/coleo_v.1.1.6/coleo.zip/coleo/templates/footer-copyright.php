<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap<?php
				if (!coleo_is_inherit(coleo_get_theme_option('copyright_scheme')))
					echo ' scheme_' . esc_attr(coleo_get_theme_option('copyright_scheme'));
 				?>">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text"><?php
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$coleo_copyright = coleo_prepare_macros(coleo_get_theme_option('copyright'));
				if (!empty($coleo_copyright)) {
					// Replace {date_format} on the current date in the specified format
					if (preg_match("/(\\{[\\w\\d\\\\\\-\\:]*\\})/", $coleo_copyright, $coleo_matches)) {
						$coleo_copyright = str_replace($coleo_matches[1], date_i18n(str_replace(array('{', '}'), '', $coleo_matches[1])), $coleo_copyright);
					}
					// Display copyright
					echo nl2br($coleo_copyright);
				}
			?></div>
		</div>
	</div>
</div>
