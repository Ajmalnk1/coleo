<?php
/**
 * The template to display the widgets area in the header
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

// Header sidebar
$coleo_header_name = coleo_get_theme_option('header_widgets');
$coleo_header_present = !coleo_is_off($coleo_header_name) && is_active_sidebar($coleo_header_name);
if ($coleo_header_present) { 
	coleo_storage_set('current_sidebar', 'header');
	$coleo_header_wide = coleo_get_theme_option('header_wide');
	ob_start();
	if ( is_active_sidebar($coleo_header_name) ) {
		dynamic_sidebar($coleo_header_name);
	}
	$coleo_widgets_output = ob_get_contents();
	ob_end_clean();
	if (!empty($coleo_widgets_output)) {
		$coleo_widgets_output = preg_replace("/<\/aside>[\r\n\s]*<aside/", "</aside><aside", $coleo_widgets_output);
		$coleo_need_columns = strpos($coleo_widgets_output, 'columns_wrap')===false;
		if ($coleo_need_columns) {
			$coleo_columns = max(0, (int) coleo_get_theme_option('header_columns'));
			if ($coleo_columns == 0) $coleo_columns = min(6, max(1, substr_count($coleo_widgets_output, '<aside ')));
			if ($coleo_columns > 1)
				$coleo_widgets_output = preg_replace("/<aside([^>]*)class=\"widget/", "<aside$1class=\"column-1_".esc_attr($coleo_columns).' widget', $coleo_widgets_output);
			else
				$coleo_need_columns = false;
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo !empty($coleo_header_wide) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<div class="header_widgets_inner widget_area_inner">
				<?php 
				if (!$coleo_header_wide) { 
					?><div class="content_wrap"><?php
				}
				if ($coleo_need_columns) {
					?><div class="columns_wrap"><?php
				}
				do_action( 'coleo_action_before_sidebar' );
				coleo_show_layout($coleo_widgets_output);
				do_action( 'coleo_action_after_sidebar' );
				if ($coleo_need_columns) {
					?></div>	<!-- /.columns_wrap --><?php
				}
				if (!$coleo_header_wide) {
					?></div>	<!-- /.content_wrap --><?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
?>