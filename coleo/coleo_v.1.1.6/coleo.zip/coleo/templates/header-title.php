<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

// Page (category, tag, archive, author) title

if ( coleo_need_page_title() ) {
	coleo_sc_layouts_showed('title', true);
	coleo_sc_layouts_showed('postmeta', true);
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() )  {
							?><div class="sc_layouts_title_meta"><?php
								coleo_show_post_meta(apply_filters('coleo_filter_post_meta_args', array(
									'components' => coleo_array_get_keys_by_value(coleo_get_theme_option('meta_parts')),
									'counters' => coleo_array_get_keys_by_value(coleo_get_theme_option('counters')),
									'seo' => coleo_is_on(coleo_get_theme_option('seo_snippets'))
									), 'header', 1)
								);
							?></div><?php
						}
						
						// Blog/Post title
						?><div class="sc_layouts_title_title"><?php
							$coleo_blog_title = coleo_get_blog_title();
							$coleo_blog_title_text = $coleo_blog_title_class = $coleo_blog_title_link = $coleo_blog_title_link_text = '';
							if (is_array($coleo_blog_title)) {
								$coleo_blog_title_text = $coleo_blog_title['text'];
								$coleo_blog_title_class = !empty($coleo_blog_title['class']) ? ' '.$coleo_blog_title['class'] : '';
								$coleo_blog_title_link = !empty($coleo_blog_title['link']) ? $coleo_blog_title['link'] : '';
								$coleo_blog_title_link_text = !empty($coleo_blog_title['link_text']) ? $coleo_blog_title['link_text'] : '';
							} else
								$coleo_blog_title_text = $coleo_blog_title;
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr($coleo_blog_title_class); ?>"><?php
								$coleo_top_icon = coleo_get_category_icon();
								if (!empty($coleo_top_icon)) {
									$coleo_attr = coleo_getimagesize($coleo_top_icon);
									?><img src="<?php echo esc_url($coleo_top_icon); ?>" alt="<?php echo esc_attr(basename($coleo_top_icon)); ?>" <?php if (!empty($coleo_attr[3])) coleo_show_layout($coleo_attr[3]);?>><?php
								}
								echo wp_kses($coleo_blog_title_text, 'coleo_kses_content');
							?></h1>
							<?php
							if (!empty($coleo_blog_title_link) && !empty($coleo_blog_title_link_text)) {
								?><a href="<?php echo esc_url($coleo_blog_title_link); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html($coleo_blog_title_link_text); ?></a><?php
							}
							
							// Category/Tag description
							if ( is_category() || is_tag() || is_tax() ) 
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
		
						?></div><?php
	
						// Breadcrumbs
						?><div class="sc_layouts_title_breadcrumbs"><?php
							do_action( 'coleo_action_breadcrumbs');
						?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
?>