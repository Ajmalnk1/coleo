<?php
/**
 * The template to display default site footer
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0.10
 */

$coleo_footer_id = str_replace('footer-custom-', '', coleo_get_theme_option("footer_style"));
if ((int) $coleo_footer_id == 0) {
	$coleo_footer_id = coleo_get_post_id(array(
												'name' => $coleo_footer_id,
												'post_type' => defined('TRX_ADDONS_CPT_LAYOUTS_PT') ? TRX_ADDONS_CPT_LAYOUTS_PT : 'cpt_layouts'
												)
											);
} else {
	$coleo_footer_id = apply_filters('coleo_filter_get_translated_layout', $coleo_footer_id);
}
$coleo_footer_meta = get_post_meta($coleo_footer_id, 'trx_addons_options', true);
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr($coleo_footer_id); 
						?> footer_custom_<?php echo esc_attr(sanitize_title(get_the_title($coleo_footer_id))); 
						if (!empty($coleo_footer_meta['margin']) != '') 
							echo ' '.esc_attr(coleo_add_inline_css_class('margin-top: '.coleo_prepare_css_value($coleo_footer_meta['margin']).';'));
						if (!coleo_is_inherit(coleo_get_theme_option('footer_scheme')))
							echo ' scheme_' . esc_attr(coleo_get_theme_option('footer_scheme'));
						?>">
	<?php
    // Custom footer's layout
    do_action('coleo_action_show_layout', $coleo_footer_id);
	?>
</footer><!-- /.footer_wrap -->
