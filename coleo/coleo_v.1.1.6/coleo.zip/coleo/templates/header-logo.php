<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

$coleo_args = get_query_var('coleo_logo_args');

// Site logo
$coleo_logo_type   = isset($coleo_args['type']) ? $coleo_args['type'] : '';
$coleo_logo_image  = coleo_get_logo_image($coleo_logo_type);
$coleo_logo_text   = coleo_is_on(coleo_get_theme_option('logo_text')) ? get_bloginfo( 'name' ) : '';
$coleo_logo_slogan = get_bloginfo( 'description', 'display' );
if (!empty($coleo_logo_image) || !empty($coleo_logo_text)) {
	?><a class="sc_layouts_logo" href="<?php echo is_front_page() ? '#' : esc_url(home_url('/')); ?>"><?php
		if (!empty($coleo_logo_image)) {
			if (empty($coleo_logo_type) && function_exists('the_custom_logo') && (int) is_numeric( $coleo_logo_image ) && $coleo_logo_image > 0) {
				the_custom_logo();
			} else {
				$coleo_attr = coleo_getimagesize($coleo_logo_image);
				echo '<img src="'.esc_url($coleo_logo_image).'" alt="'.esc_attr(basename($coleo_logo_image)).'"'.(!empty($coleo_attr[3]) ? ' '.wp_kses_data($coleo_attr[3]) : '').'>';
			}
		} else {
			coleo_show_layout(coleo_prepare_macros($coleo_logo_text), '<span class="logo_text">', '</span>');
			coleo_show_layout(coleo_prepare_macros($coleo_logo_slogan), '<span class="logo_slogan">', '</span>');
		}
	?></a><?php
}
?>