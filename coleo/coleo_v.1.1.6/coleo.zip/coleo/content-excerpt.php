<?php
/**
 * The default template to display the content
 *
 * Used for index/archive/search.
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

$coleo_post_format = get_post_format();
$coleo_post_format = empty($coleo_post_format) ? 'standard' : str_replace('post-format-', '', $coleo_post_format);
$coleo_animation = coleo_get_theme_option('blog_animation');

?><article id="post-<?php the_ID(); ?>" 
	<?php post_class( 'post_item post_layout_excerpt post_format_'.esc_attr($coleo_post_format) ); ?>
	<?php echo (!coleo_is_off($coleo_animation) ? ' data-animation="'.esc_attr(coleo_get_animation_classes($coleo_animation)).'"' : ''); ?>
	><?php

	do_action('coleo_action_before_post_meta'); 

	// Post meta
	$coleo_components = coleo_array_get_keys_by_value(coleo_get_theme_option('meta_parts'));
	$coleo_counters = coleo_array_get_keys_by_value(coleo_get_theme_option('counters'));
    $res = coleo_get_post_meta_array(apply_filters('coleo_filter_post_meta_args', array(
        'components' => $coleo_components,
        'counters' => $coleo_counters,
        'seo' => false,
        'echo' => false
        ), 'excerpt', 1)
    );
	// Post Date
	if (!empty($res['date'])) ?><div class="blog_date"><?php {coleo_show_layout($res['date']); } ?></div><?php

	// Sticky label
	if ( is_sticky() && !is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}
	// Featured image
	coleo_show_post_featured(array( 'thumb_size' => coleo_get_thumb_size( strpos(coleo_get_theme_option('body_style'), 'full')!==false ? 'full' : 'big' ) ));	
    ?>
    <div class="over_head">
    	<div class="blog_cat">
			<?php if (!empty($res['categories'])){coleo_show_layout($res['categories']);} ?>
		    <?php if (!empty($res['author'])){coleo_show_layout($res['author']);} ?>
		    <?php if (!empty($res['comments'])){coleo_show_layout($res['comments']);} ?>
    	</div>
	    <div class="blog_share">
	    	<?php if (!empty($res['share'])){coleo_show_layout($res['share']); } ?>
	    	<?php if (!empty($res['views'])){coleo_show_layout($res['views']); } ?>
	    	<?php if (!empty($res['likes'])){coleo_show_layout($res['likes']);} ?>
	    </div>
    </div>
    <?php
	// Title and post meta
	if (get_the_title() != '') {
		?>		
		<div class="post_header entry-header">
			<?php
			do_action('coleo_action_before_post_title'); 

			// Post title
			the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );

			?>
		</div><!-- .post_header --><?php
	}
	
	// Post content
	?><div class="post_content entry-content"><?php
		if (coleo_get_theme_option('blog_content') == 'fullpost') {
			// Post content area
			?><div class="post_content_inner"><?php
				the_content( '' );
			?></div><?php
			// Inner pages
			wp_link_pages( array(
				'before'      => '<div class="page_links"><span class="page_links_title">' . esc_html__( 'Pages:', 'coleo' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'coleo' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );

		} else {

			$coleo_show_learn_more = !in_array($coleo_post_format, array('link', 'aside', 'status', 'quote'));

			// Post content area
			?><div class="post_content_inner"><?php
			?></div><?php
			// More button
			if ( $coleo_show_learn_more ) {
				?><p><a class="more-link" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'coleo'); ?></a></p><?php
			}

		}
	?></div><!-- .entry-content -->
</article>