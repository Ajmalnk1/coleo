<?php
/**
 * The template for homepage posts with "Portfolio" style
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

coleo_storage_set('blog_archive', true);

get_header(); 

if (have_posts()) {

	coleo_show_layout(get_query_var('blog_archive_start'));

	$coleo_stickies = is_home() ? get_option( 'sticky_posts' ) : false;
	$coleo_sticky_out = coleo_get_theme_option('sticky_style')=='columns' 
							&& is_array($coleo_stickies) && count($coleo_stickies) > 0 && get_query_var( 'paged' ) < 1;
	
	// Show filters
	$coleo_cat = coleo_get_theme_option('parent_cat');
	$coleo_post_type = coleo_get_theme_option('post_type');
	$coleo_taxonomy = coleo_get_post_type_taxonomy($coleo_post_type);
	$coleo_show_filters = coleo_get_theme_option('show_filters');
	$coleo_tabs = array();
	if (!coleo_is_off($coleo_show_filters)) {
		$coleo_args = array(
			'type'			=> $coleo_post_type,
			'child_of'		=> $coleo_cat,
			'orderby'		=> 'name',
			'order'			=> 'ASC',
			'hide_empty'	=> 1,
			'hierarchical'	=> 0,
			'exclude'		=> '',
			'include'		=> '',
			'number'		=> '',
			'taxonomy'		=> $coleo_taxonomy,
			'pad_counts'	=> false
		);
		$coleo_portfolio_list = get_terms($coleo_args);
		if (is_array($coleo_portfolio_list) && count($coleo_portfolio_list) > 0) {
			$coleo_tabs[$coleo_cat] = esc_html__('All', 'coleo');
			foreach ($coleo_portfolio_list as $coleo_term) {
				if (isset($coleo_term->term_id)) $coleo_tabs[$coleo_term->term_id] = $coleo_term->name;
			}
		}
	}
	if (count($coleo_tabs) > 0) {
		$coleo_portfolio_filters_ajax = true;
		$coleo_portfolio_filters_active = $coleo_cat;
		$coleo_portfolio_filters_id = 'portfolio_filters';
		?>
		<div class="portfolio_filters coleo_tabs coleo_tabs_ajax">
			<ul class="portfolio_titles coleo_tabs_titles">
				<?php
				foreach ($coleo_tabs as $coleo_id=>$coleo_title) {
					?><li><a href="<?php echo esc_url(coleo_get_hash_link(sprintf('#%s_%s_content', $coleo_portfolio_filters_id, $coleo_id))); ?>" data-tab="<?php echo esc_attr($coleo_id); ?>"><?php echo esc_html($coleo_title); ?></a></li><?php
				}
				?>
			</ul>
			<?php
			$coleo_ppp = coleo_get_theme_option('posts_per_page');
			if (coleo_is_inherit($coleo_ppp)) $coleo_ppp = '';
			foreach ($coleo_tabs as $coleo_id=>$coleo_title) {
				$coleo_portfolio_need_content = $coleo_id==$coleo_portfolio_filters_active || !$coleo_portfolio_filters_ajax;
				?>
				<div id="<?php echo esc_attr(sprintf('%s_%s_content', $coleo_portfolio_filters_id, $coleo_id)); ?>"
					class="portfolio_content coleo_tabs_content"
					data-blog-template="<?php echo esc_attr(coleo_storage_get('blog_template')); ?>"
					data-blog-style="<?php echo esc_attr(coleo_get_theme_option('blog_style')); ?>"
					data-posts-per-page="<?php echo esc_attr($coleo_ppp); ?>"
					data-post-type="<?php echo esc_attr($coleo_post_type); ?>"
					data-taxonomy="<?php echo esc_attr($coleo_taxonomy); ?>"
					data-cat="<?php echo esc_attr($coleo_id); ?>"
					data-parent-cat="<?php echo esc_attr($coleo_cat); ?>"
					data-need-content="<?php echo (false===$coleo_portfolio_need_content ? 'true' : 'false'); ?>"
				>
					<?php
					if ($coleo_portfolio_need_content) 
						coleo_show_portfolio_posts(array(
							'cat' => $coleo_id,
							'parent_cat' => $coleo_cat,
							'taxonomy' => $coleo_taxonomy,
							'post_type' => $coleo_post_type,
							'page' => 1,
							'sticky' => $coleo_sticky_out
							)
						);
					?>
				</div>
				<?php
			}
			?>
		</div>
		<?php
	} else {
		coleo_show_portfolio_posts(array(
			'cat' => $coleo_cat,
			'parent_cat' => $coleo_cat,
			'taxonomy' => $coleo_taxonomy,
			'post_type' => $coleo_post_type,
			'page' => 1,
			'sticky' => $coleo_sticky_out
			)
		);
	}

	coleo_show_layout(get_query_var('blog_archive_end'));

} else {

	if ( is_search() )
		get_template_part( 'content', 'none-search' );
	else
		get_template_part( 'content', 'none-archive' );

}

get_footer();
?>