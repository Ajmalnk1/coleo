<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package WordPress
 * @subpackage COLEO
 * @since COLEO 1.0
 */

						// Widgets area inside page content
						coleo_create_widgets_area('widgets_below_content');
						?>				
					</div><!-- </.content> -->

					<?php
					// Show main sidebar
					get_sidebar();

					// Widgets area below page content
					coleo_create_widgets_area('widgets_below_page');

					$coleo_body_style = coleo_get_theme_option('body_style');
					if ($coleo_body_style != 'fullscreen') {
						?></div><!-- </.content_wrap> --><?php
					}
					?>
			</div><!-- </.page_content_wrap> -->

			<?php
			// Footer
			$coleo_footer_type = coleo_get_theme_option("footer_type");
			if ($coleo_footer_type == 'custom' && !coleo_is_layouts_available())
				$coleo_footer_type = 'default';
			get_template_part( "templates/footer-{$coleo_footer_type}");
			?>

		</div><!-- /.page_wrap -->

	</div><!-- /.body_wrap -->

	<?php if (coleo_is_on(coleo_get_theme_option('debug_mode')) && coleo_get_file_dir('images/makeup.jpg')!='') { ?>
		<img src="<?php echo esc_url(coleo_get_file_url('images/makeup.jpg')); ?>" id="makeup">
	<?php } ?>

	<?php wp_footer(); ?>

</body>
</html>