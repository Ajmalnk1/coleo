<div class="front_page_section front_page_section_subscribe<?php
			$coleo_scheme = coleo_get_theme_option('front_page_subscribe_scheme');
			if (!coleo_is_inherit($coleo_scheme)) echo ' scheme_'.esc_attr($coleo_scheme);
			echo ' front_page_section_paddings_'.esc_attr(coleo_get_theme_option('front_page_subscribe_paddings'));
		?>"<?php
		$coleo_css = '';
		$coleo_bg_image = coleo_get_theme_option('front_page_subscribe_bg_image');
		if (!empty($coleo_bg_image)) 
			$coleo_css .= 'background-image: url('.esc_url(coleo_get_attachment_url($coleo_bg_image)).');';
		if (!empty($coleo_css))
			echo ' style="' . esc_attr($coleo_css) . '"';
?>><?php
	// Add anchor
	$coleo_anchor_icon = coleo_get_theme_option('front_page_subscribe_anchor_icon');	
	$coleo_anchor_text = coleo_get_theme_option('front_page_subscribe_anchor_text');	
	if ((!empty($coleo_anchor_icon) || !empty($coleo_anchor_text)) && shortcode_exists('trx_sc_anchor')) {
		echo do_shortcode('[trx_sc_anchor id="front_page_section_subscribe"'
										. (!empty($coleo_anchor_icon) ? ' icon="'.esc_attr($coleo_anchor_icon).'"' : '')
										. (!empty($coleo_anchor_text) ? ' title="'.esc_attr($coleo_anchor_text).'"' : '')
										. ']');
	}
	?>
	<div class="front_page_section_inner front_page_section_subscribe_inner<?php
			if (coleo_get_theme_option('front_page_subscribe_fullheight'))
				echo ' coleo-full-height sc_layouts_flex sc_layouts_columns_middle';
			?>"<?php
			$coleo_css = '';
			$coleo_bg_mask = coleo_get_theme_option('front_page_subscribe_bg_mask');
			$coleo_bg_color = coleo_get_theme_option('front_page_subscribe_bg_color');
			if (!empty($coleo_bg_color) && $coleo_bg_mask > 0)
				$coleo_css .= 'background-color: '.esc_attr($coleo_bg_mask==1
																	? $coleo_bg_color
																	: coleo_hex2rgba($coleo_bg_color, $coleo_bg_mask)
																).';';
			if (!empty($coleo_css))
				echo ' style="' . esc_attr($coleo_css) . '"';
	?>>
		<div class="front_page_section_content_wrap front_page_section_subscribe_content_wrap content_wrap">
			<?php
			// Caption
			$coleo_caption = coleo_get_theme_option('front_page_subscribe_caption');
			if (!empty($coleo_caption) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><h2 class="front_page_section_caption front_page_section_subscribe_caption front_page_block_<?php echo !empty($coleo_caption) ? 'filled' : 'empty'; ?>"><?php echo wp_kses($coleo_caption, 'coleo_kses_content'); ?></h2><?php
			}
		
			// Description (text)
			$coleo_description = coleo_get_theme_option('front_page_subscribe_description');
			if (!empty($coleo_description) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><div class="front_page_section_description front_page_section_subscribe_description front_page_block_<?php echo !empty($coleo_description) ? 'filled' : 'empty'; ?>"><?php echo wp_kses(wpautop($coleo_description), 'coleo_kses_content'); ?></div><?php
			}
			
			// Content
			$coleo_sc = coleo_get_theme_option('front_page_subscribe_shortcode');
			if (!empty($coleo_sc) || (current_user_can('edit_theme_options') && is_customize_preview())) {
				?><div class="front_page_section_output front_page_section_subscribe_output front_page_block_<?php echo !empty($coleo_sc) ? 'filled' : 'empty'; ?>"><?php
					coleo_show_layout(do_shortcode($coleo_sc));
				?></div><?php
			}
			?>
		</div>
	</div>
</div>